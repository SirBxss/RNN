import copy

import numpy as np
from copy import deepcopy


class NeuralNetwork:
    def __init__(self, optimizer, weight_initializer=None, bias_initializer = None):
        self.optimizer = optimizer
        self.loss = []  # List to store loss value for each iteration
        self.layers = []  # List to hold the architecture
        self.data_layer = None  # Placeholder for data layer (input data and labels)
        self.loss_layer = None  # Placeholder for loss layer (special layer providing loss and prediction)
        self.weights_initializer = weight_initializer
        self.bias_initializer = bias_initializer

    # def forward(self):
    #     # Get input and labels from data layer
    #     input_tensor, self.label_tensor = self.data_layer.next()
    #     regularize_loss = 0
    #     # Forward pass through all layers
    #     for layer in self.layers:
    #         layer.testing_phase = False
    #         input_tensor = layer.forward(input_tensor)
    #         if self.optimizer.regularizer is not None:
    #             regularize_loss += self.optimizer.regularizer.norm(layer.weights)
    #     global_loss = self.loss_layer.forward(input_tensor, copy.deepcopy(self.label_tensor))
    #
    #     # Store the label tensor for backward pass
    #     # self.label_tensor = label_tensor
    #
    #     # output = self.loss_layer.forward(input_tensor, label_tensor)
    #
    #     output = global_loss + regularize_loss
    #
    #     return output

    # def forward(self):
    #     # Get input and labels from data layer
    #     input_tensor, label_tensor = self.data_layer.next()
    #
    #     # Forward pass through all layers
    #     for layer in self.layers:
    #         input_tensor = layer.forward(input_tensor)
    #
    #     # Store the label tensor for backward pass
    #     self.label_tensor = label_tensor
    #
    #     output = self.loss_layer.forward(input_tensor, label_tensor)
    #
    #     return output

    # def forward(self):
    #     data, self.label_tensor = copy.deepcopy(self.data_layer.next())
    #     reg_loss = 0
    #     for layer in self.layers:
    #         layer.testing_phase = False
    #         data = layer.forward(data)
    #         if self.optimizer.regularizer is not None:
    #             if hasattr(layer, 'weights'):
    #                 reg_loss += self.optimizer.regularizer.norm(layer.weights)
    #                 print(f"WEIGHTS : \n{layer.weights}")
    #                 print(f"REGULARIZE LOSS : \n{reg_loss}")
    #     glob_loss = self.loss_layer.forward(data, copy.deepcopy(self.label_tensor))
    #     print(f"GLOBAL LOSS : {glob_loss}")
    #     return glob_loss + reg_loss

    def forward(self):
        data, self.label_tensor = copy.deepcopy(self.data_layer.next())
        reg_loss = 0
        for layer in self.layers:
            layer.testing_phase = False
            data = layer.forward(data)
            if self.optimizer.regularizer is not None:
                if hasattr(layer, 'weights'):
                    reg_loss += self.optimizer.regularizer.norm(layer.weights)
                    print(f"Layer: {layer.__class__.__name__}")
                    print(f"Weights:\n{layer.weights}")
                    print(f"Regularization Loss (so far): {reg_loss}")
        glob_loss = self.loss_layer.forward(data, copy.deepcopy(self.label_tensor))
        print(f"Global Loss (before regularization): {glob_loss}")
        total_loss = glob_loss + reg_loss
        print(f"Total Loss (after regularization): {total_loss}")
        return total_loss



    def backward(self):
        # Start the backward pass from the loss layer using the stored label tensor
        error_tensor = self.loss_layer.backward(self.label_tensor)

        # Propagate the error tensor through all layers in reverse order
        for layer in reversed(self.layers):
            error_tensor = layer.backward(error_tensor)

    def append_layer(self, layer):
        if layer.trainable:
            layer.optimizer = deepcopy(self.optimizer)
            layer.initialize(self.weights_initializer, self.bias_initializer)
        self.layers.append(layer)

    def train(self, iterations):
        self.phase = 'train'
        for _ in range(iterations):
            loss = self.forward()
            print(f"LOSS FOR NEURAL NETWORK : {loss}")
            self.backward()
            # Calculate and store the loss for the current iteration
            self.loss.append(loss)

    def test(self, input_tensor):
        self.phase = 'test'
        # Forward pass through all layers using the input tensor
        for layer in self.layers:
            layer.testing_phase = True
            input_tensor = layer.forward(input_tensor)

        return input_tensor

    @property
    def phase(self):
        return self._phase

    @phase.setter
    def phase(self, phase):
        self._phase = phase
